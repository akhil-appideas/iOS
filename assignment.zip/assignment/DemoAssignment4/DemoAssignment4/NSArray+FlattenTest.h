//
//  NSArray+FlattenTest.h
//  DemoAssignment4
//
//  Created by Shailendra Kumar on 12/04/16.
//  Copyright © 2016 Appideas Sofware Solutions. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (FlattenTest)
@property (nonatomic, readonly) NSArray *flattened;

@end
