//
//  AppDelegate.h
//  DemoAssignmentNo5
//
//  Created by Shailendra Kumar on 12/04/16.
//  Copyright © 2016 Appideas Sofware Solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

